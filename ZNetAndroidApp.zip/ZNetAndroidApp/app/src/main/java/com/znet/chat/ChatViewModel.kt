package com.znet.chat

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel

class ChatViewModel : ViewModel() {

    val messages =
        mutableStateListOf<ChatMessage>()

    fun addMessage(msg: ChatMessage) {

        messages.add(msg)
    }
}
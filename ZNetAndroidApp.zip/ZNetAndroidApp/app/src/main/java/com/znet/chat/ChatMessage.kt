package com.znet.chat

data class ChatMessage(

    val sender: String,

    val message: String,

    val mine: Boolean = false
)
package com.znet.chat

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items

import androidx.compose.material3.*

import androidx.compose.runtime.*

import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import androidx.core.content.ContextCompat

import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {

    private val bt = BluetoothService()

    private val permissionsLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {
        }

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        askPermissions()

        setContent {

            val vm: ChatViewModel = viewModel()

            var connected by remember {
                mutableStateOf(false)
            }

            var username by remember {
                mutableStateOf("Rodrigo")
            }

            var text by remember {
                mutableStateOf("")
            }

            LaunchedEffect(Unit) {

                connected = bt.connectToZNet()

                if (connected) {

                    bt.listen { raw ->

                        val parts = raw.split("|")

                        if (parts.size >= 3) {

                            vm.addMessage(
                                ChatMessage(
                                    sender = parts[1],
                                    message = parts[2],
                                    mine = false
                                )
                            )
                        }
                    }
                }
            }

            MaterialTheme {

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {

                    Text(
                        text = if (connected)
                            "Connected to ZNet"
                        else
                            "Disconnected"
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = {
                            username = it
                        },
                        label = {
                            Text("Username")
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(
                        modifier = Modifier.height(8.dp)
                    )

                    LazyColumn(
                        modifier = Modifier.weight(1f)
                    ) {

                        items(vm.messages) { msg ->

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(4.dp)
                            ) {

                                Column(
                                    modifier = Modifier.padding(8.dp)
                                ) {

                                    Text(msg.sender)

                                    Spacer(
                                        modifier = Modifier.height(4.dp)
                                    )

                                    Text(msg.message)
                                }
                            }
                        }
                    }

                    Row {

                        OutlinedTextField(
                            value = text,
                            onValueChange = {
                                text = it
                            },
                            modifier = Modifier.weight(1f),
                            label = {
                                Text("Message")
                            }
                        )

                        Spacer(
                            modifier = Modifier.width(8.dp)
                        )

                        Button(
                            onClick = {

                                bt.send(
                                    username,
                                    text
                                )

                                vm.addMessage(
                                    ChatMessage(
                                        sender = username,
                                        message = text,
                                        mine = true
                                    )
                                )

                                text = ""
                            }
                        ) {

                            Text("Send")
                        }
                    }
                }
            }
        }
    }

    private fun askPermissions() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {

            val permissions = arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            )

            val missing = permissions.filter {

                ContextCompat.checkSelfPermission(
                    this,
                    it
                ) != PackageManager.PERMISSION_GRANTED
            }

            if (missing.isNotEmpty()) {

                permissionsLauncher.launch(
                    missing.toTypedArray()
                )
            }
        }
    }
}
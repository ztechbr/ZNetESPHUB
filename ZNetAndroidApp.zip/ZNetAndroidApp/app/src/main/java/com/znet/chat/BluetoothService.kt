package com.znet.chat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream

import java.util.UUID

class BluetoothService {

    private val adapter =
        BluetoothAdapter.getDefaultAdapter()

    private var socket: BluetoothSocket? = null

    private var output: OutputStream? = null

    private val uuid =
        UUID.fromString(
            "00001101-0000-1000-8000-00805F9B34FB"
        )

    @SuppressLint("MissingPermission")
    fun connectToZNet(): Boolean {

        return try {

            val device =
                adapter.bondedDevices.firstOrNull {
                    it.name == "ZNet"
                }

            if (device == null)
                return false

            socket =
                device.createRfcommSocketToServiceRecord(uuid)

            adapter.cancelDiscovery()

            socket?.connect()

            output = socket?.outputStream

            true

        } catch (e: Exception) {

            false
        }
    }

    fun listen(
        onMessage: (String) -> Unit
    ) {

        Thread {

            try {

                val reader = BufferedReader(
                    InputStreamReader(
                        socket?.inputStream
                    )
                )

                while (true) {

                    val line = reader.readLine()

                    if (line != null) {

                        onMessage(line)
                    }
                }

            } catch (e: Exception) {

                e.printStackTrace()
            }

        }.start()
    }

    fun send(
        username: String,
        text: String
    ) {

        try {

            val payload =
                "MSG|$username|$text\n"

            output?.write(
                payload.toByteArray()
            )

        } catch (e: Exception) {

            e.printStackTrace()
        }
    }
}
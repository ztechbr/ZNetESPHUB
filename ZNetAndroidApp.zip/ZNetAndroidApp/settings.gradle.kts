rootProject.name = "ZNet"
include(":app")